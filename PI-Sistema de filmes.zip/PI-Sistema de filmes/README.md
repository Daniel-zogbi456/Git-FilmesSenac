# Git-FilmesSenac

Repositório remoto do projeto integrador do curso TDS do Senac. Envolve uma aplicação de filmes.

Status- Em desenvolvimento

Tecnologias Aplicadas: GitBash e Hub - Java(Aplicação Base) - HTML,CSS,JavaScript(Parte Web), MySQL(Banco de dados)

Devs: Daniel Machado

Objetivo: Criar uma aplicação web(Site) baseado na aplicação Java anteriormente criada do Senac Filmes.

Funcionalidades do Sistema: Cadastro e Avaliação de filmes, Cadastro de avaliadores, conexão com banco de dados.

