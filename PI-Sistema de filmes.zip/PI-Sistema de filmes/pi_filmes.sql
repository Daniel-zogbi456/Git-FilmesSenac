create database pi_filmes;

use pi_filmes;

create table filmes (
 id_Filme int not null auto_increment,
 nome_Filme varchar(50),
 tempo_Filme varchar(50),
 idade_Filme varchar(2),
 genero_Filme varchar(50),
 estudio_Filme varchar(50),
 primary key (id_Filme)
) ;

create table avaliadores(
id_Av int not null auto_increment,
usuario_Av varchar(50) not null,
senha_Av varchar(50) not null,
primary key(id_Av)
);

create table moderadores(
id_Mod int not null auto_increment,
usuario_Mod varchar(50) not null,
senha_Mod varchar(50) not null,
primary key(id_Mod)
);
