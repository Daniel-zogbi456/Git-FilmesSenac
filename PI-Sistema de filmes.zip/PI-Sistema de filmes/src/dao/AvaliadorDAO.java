/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Conexao.Conector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Avaliador;
import java.sql.ResultSet;

public class AvaliadorDAO {
 private Conector conexao;
 private Connection conn;
 
 public AvaliadorDAO() {
                    this.conexao = new Conector();
                    this.conn = this.conexao.getConexao();
                }
            
 
  public void inserirA(Avaliador avaliador) {
                    String sql = "INSERT INTO avaliadores(usuario_Av, senha_Av) VALUES "
                            + "(?, ?)";
                    try {
                        PreparedStatement stmt = this.conn.prepareStatement(sql);
                        stmt.setString(1, avaliador.getUsuario());
                        stmt.setString(2, avaliador.getSenha());
                        
                        stmt.execute();
            
                    } catch (Exception e) {
                        System.out.println("Erro ao inserir avaliador: " + e.getMessage());
                    }
                }  
 
 
 public void editar (Avaliador avaliador){
                //string sql com o código de update para o banco de dados
                String sql = "UPDATE avaliadores SET usuario_Av=?, senha_Av=?  WHERE id=?";
                try {
                    //esse trecho é igual ao método inserir
                    PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);
                    //Setando os parâmetros
                    stmt.setString(1, avaliador.getUsuario());
                    stmt.setString(2, avaliador.getSenha());
                    stmt.setInt(3, avaliador.getId());
                    //Executando a query
                    stmt.execute();
                    //tratando o erro, caso ele ocorra
                } catch (Exception e) {
                    System.out.println("Erro ao editar avaliador: " + e.getMessage());
                }
            }
 
 
 public Avaliador getAvaliador (String usuario, String senha){
      String sql = "SELECT * FROM avaliadores WHERE usuario_Av= ?, senha_Av=? ";
      try {
                  
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          ResultSet rs = stmt.executeQuery();
        
          Avaliador avaliador = new Avaliador();
          
          rs.next(); 
          
          
          avaliador.setUsuario(rs.getString("usuario_Av"));
          avaliador.setSenha(rs.getString("senha_Av"));
         
          return avaliador;
          
          //tratando o erro, caso ele ocorra
      } catch (Exception e) {
          System.out.println("erro: " + e.getMessage());
          return null;
      }
  } 
 
 
}
