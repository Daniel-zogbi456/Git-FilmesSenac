
package dao;
import Conexao.Conector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Moderador;
import java.sql.ResultSet;


public class ModeradorDAO {
    private Conector conexao;
 private Connection conn;
 
 public ModeradorDAO() {
                    this.conexao = new Conector();
                    this.conn = this.conexao.getConexao();
                }
            
                public void inserir(Moderador moderador) {
                    String sql = "INSERT INTO moderadores(usuario_Mod, senha_Mod) VALUES "
                            + "(?, ?)";
                    try {
                        PreparedStatement stmt = this.conn.prepareStatement(sql);
                        stmt.setString(1, moderador.getUsuario());
                        stmt.setString(2, moderador.getSenha());
                        stmt.execute();
            
                    } catch (Exception e) {
                        System.out.println("Erro ao inserir avaliador: " + e.getMessage());
                    }
                }
                
                
                
     public Moderador getModerador (String usuario, String senha){
      String sql = "SELECT * FROM moderadores WHERE usuario_Mod= ?, senha_Mod=? ";
      try {
                  
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          ResultSet rs = stmt.executeQuery();
        
          Moderador moderador = new Moderador();
          
          rs.next(); 
          
          
          moderador.setUsuario(rs.getString("usuario_Mod"));
          moderador.setSenha(rs.getString("senha_Mod"));
         
          return moderador;
          
          //tratando o erro, caso ele ocorra
      } catch (Exception e) {
          System.out.println("erro: " + e.getMessage());
          return null;
      }
  } 
                
                
                
}
