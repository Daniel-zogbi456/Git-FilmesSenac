/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import Conexao.Conector;
import model.Filme;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Connection;


public class FilmeDAO {
    private Conector conexao;
    private Connection conn;

    /**construtor**/
    public FilmeDAO() {
                this.conexao = new Conector();
                this.conn = this.conexao.getConexao();

    }
    
    public void inserir(Filme filme) {
                    String sql = "INSERT INTO filmes(nome_Filme, tempo_Filme,idade_Filme,genero_Filme,estudio_Filme) VALUES "
                            + "(?, ?,?,?,?)";
                    try {
                        PreparedStatement stmt = this.conn.prepareStatement(sql);
                        stmt.setString(1, filme.getNomeF());
                        stmt.setString(2, filme.getTempo());
                        stmt.setString(3, filme.getClsIdade());
                        stmt.setString(4, filme.getGenero());
                        stmt.setString(5, filme.getEstudio());
                        stmt.execute();
            
                    } catch (Exception e) {
                        System.out.println("Erro ao inserir filme: " + e.getMessage());
                    }
                }  
    
     public List<Filme> getFilme() {
                String sql = "SELECT * FROM filmes";
                
                try {
                    PreparedStatement stmt = this.conn.prepareStatement(sql);
                    ResultSet rs = stmt.executeQuery();            
                    
                    List<Filme> listaFilmes = new ArrayList<>();
                    
                    while (rs.next()) { //.next retorna verdadeiro caso exista uma próxima posição dentro do array
                        Filme filme = new Filme();
                       
                        filme.setNomeF(rs.getString("nome_Filme"));
                        filme.setTempo(rs.getString("tempo_Filme"));
                        filme.setClsIdade(rs.getString("idade_Filme"));
                        filme.setGenero(rs.getString("genero_Filme"));
                        filme.setEstudio(rs.getString("estudio_Filme"));
                        
                        listaFilmes.add(filme);    
                    }
                    return listaFilmes;
                    
                    //Se o método entrar no "Catch" quer dizer que não encontrou nenhum filme, então damos um "return null"
                } catch (Exception e) {
                    System.out.println("erro: " + e.getMessage());
                    return null;
                }
            }
    
    public void editar (Filme filme){
                //string sql com o código de update para o banco de dados
                String sql = "UPDATE filmes SET nome_Filme=?, tempo_Filme=?, idade_Filme=?, genero_Filme=?, estudio_Filme=? WHERE id=?";
                try {
                    //esse trecho é igual ao método inserir
                    PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,
                            ResultSet.CONCUR_UPDATABLE);
                    //Setando os parâmetros
                    stmt.setString(1, filme.getNomeF());
                    stmt.setString(2, filme.getTempo());
                    stmt.setString(3, filme.getClsIdade());
                    stmt.setString(4, filme.getGenero());
                    stmt.setString(5, filme.getEstudio());
                    stmt.setInt(6, filme.getId());
                    //Executando a query
                    stmt.execute();
                    //tratando o erro, caso ele ocorra
                } catch (Exception e) {
                    System.out.println("Erro ao editar filme: " + e.getMessage());
                }
            }
    public Filme getFilmeID (int id){
      String sql = "SELECT * FROM filmes WHERE id = ?";
      try {
                  
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          stmt.setInt(1, id);
          ResultSet rs = stmt.executeQuery();
        
          Filme filme = new Filme();
          
          rs.next(); 
          filme.setId(id);
          filme.setNomeF(rs.getString("nome_Filme"));
          filme.setTempo(rs.getString("tempo_Filme"));
          filme.setClsIdade(rs.getString("idade_Filme"));
          filme.setGenero(rs.getString("genero_Filme"));
          filme.setEstudio(rs.getString("estudio_Filme"));
         
          return filme;
          
          //tratando o erro, caso ele ocorra
      } catch (Exception e) {
          System.out.println("erro: " + e.getMessage());
          return null;
      }
  } 
    
}


