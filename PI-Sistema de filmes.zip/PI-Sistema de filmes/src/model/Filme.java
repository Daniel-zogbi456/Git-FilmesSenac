
package model;

public class Filme {
    private int id;
    private String nomeF;
    private String tempo;
    private String clsIdade;
    private String genero;
    private String estudio;       

    public String getNomeF() {
        return nomeF;
    }

    public void setNomeF(String nomeF) {
        this.nomeF = nomeF;
    }

    public String getTempo() {
        return tempo;
    }

    public void setTempo(String tempo) {
        this.tempo = tempo;
    }

    public String getClsIdade() {
        return clsIdade;
    }

    public void setClsIdade(String clsIdade) {
        this.clsIdade = clsIdade;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getEstudio() {
        return estudio;
    }

    public void setEstudio(String estudio) {
        this.estudio = estudio;
    }
    
     public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}
