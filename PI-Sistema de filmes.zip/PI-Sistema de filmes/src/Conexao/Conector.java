
package Conexao;

import java.sql.Connection;
import java.sql.DriverManager;


public class Conector {
     public Connection getConexao() {
            
                    try {
                        Connection conn = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/pi_filmes","root", "dm66647892**"
                        );
                        return conn;
            
                    } catch (Exception e) {
                        System.out.println("Erro ao conectar: " + e.getMessage());
                        return null;
                    }
            
                }
}
